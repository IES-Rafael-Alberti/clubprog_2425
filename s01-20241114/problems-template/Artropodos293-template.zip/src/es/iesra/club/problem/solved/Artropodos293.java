package es.iesra.club.problem.solved;

import es.iesra.club.problem.solver.ProblemSolver;
import java.io.*;
import java.util.*;

/**
 * Clase que resuelve el problema de contar el número total de patas de artrópodos.
 */
public class Artropodos293 extends ProblemSolver {

    @Override
    protected List<String> process(List<String> inputLines) {
        List<String> outputLines = new ArrayList<>();

        // Leer el número de casos de prueba
        int numCasos = Integer.parseInt(inputLines.get(0));
        int currentLine = 1;

        // Procesar cada caso de prueba
        for (int i = 0; i < numCasos; i++) {
            // Leer la línea correspondiente al caso de prueba
            String[] tokens = inputLines.get(currentLine).split(" ");
            currentLine++;

            // Parsear los datos de entrada
            int nInsectos = Integer.parseInt(tokens[0]);
            int nAracnidos = Integer.parseInt(tokens[1]);
            int nCrustaceos = Integer.parseInt(tokens[2]);
            int nEscolopendras = Integer.parseInt(tokens[3]);
            int nAnillos = Integer.parseInt(tokens[4]);

            // Calcular el número total de patas
            // TODO

            // Añadir el resultado a la lista de salida
            outputLines.add(String.valueOf(totalPatas));
        }

        return outputLines;
    }

    // Método principal para ejecutar la solución
    public static void main(String[] args) throws IOException {
        Artropodos293 solver = new Artropodos293();
        String inputFile = "/ruta/a/input.txt";    // Ruta del archivo de entrada
        String outputFile = "/ruta/a/output.txt";  // Ruta del archivo de salida
        solver.execute(inputFile, outputFile);
    }
}