// Esquema de la entrada: número de casos
import java.util.*;

public class Solution {

  static Scanner in;

  public static void casoDePrueba() {

    // Leer los cinco números correspondientes a cada tipo de artrópodo
    int nInsectos = in.nextInt();       // Número de insectos
    int nAracnidos = in.nextInt();      // Número de arácnidos
    int nCrustaceos = in.nextInt();     // Número de crustáceos
    int nEscolopendras = in.nextInt();  // Número de escolopendras
    int nAnillos = in.nextInt();        // Número de anillos por escolopendra

    // Calcular el número total de patas
    // TODO

    // Imprimir el resultado
    System.out.println(totalPatas);

  } // casoDePrueba

  public static void main(String[] args) {

    in = new java.util.Scanner(System.in);

    int numCasos = in.nextInt();
    for (int i = 0; i < numCasos; i++)
      casoDePrueba();

  } // main

} // class Solution