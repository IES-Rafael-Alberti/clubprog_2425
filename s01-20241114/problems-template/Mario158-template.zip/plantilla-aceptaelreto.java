import java.util.*;

public class Solution {

  static Scanner in;

  public static void casoDePrueba() {

    // Leer el número de muros
    int numMuros = in.nextInt();

    // Leer las alturas de los muros
    int[] alturas = new int[numMuros];
    for (int i = 0; i < numMuros; i++) {
        alturas[i] = in.nextInt();
    }

    // Contar los saltos hacia arriba y hacia abajo
    int saltosArriba = 0;
    int saltosAbajo = 0;

    // TODO: Implementar la lógica para contar los saltos

    // Imprimir el resultado
    System.out.println(saltosArriba + " " + saltosAbajo);

  } // casoDePrueba

  public static void main(String[] args) {

    in = new java.util.Scanner(System.in);

    int numCasos = in.nextInt();
    for (int i = 0; i < numCasos; i++)
      casoDePrueba();

  } // main

} // class Solution
