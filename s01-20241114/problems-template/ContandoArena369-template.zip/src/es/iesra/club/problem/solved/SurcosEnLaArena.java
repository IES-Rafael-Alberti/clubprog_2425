package es.iesra.club.problem.solved;

import es.iesra.club.problem.solver.ProblemSolver;
import java.io.*;
import java.util.*;

/**
 * Clase que resuelve el problema "Surcos en la arena".
 */
public class SurcosEnLaArena extends ProblemSolver {

    @Override
    protected List<String> process(List<String> inputLines) {
        List<String> outputLines = new ArrayList<>();

        // Procesar cada línea de entrada hasta encontrar un 0
        for (String line : inputLines) {
            int n = Integer.parseInt(line.trim());
            if (n == 0) {
                break; // Terminar si se encuentra un 0
            }

            // Generar una cadena con 'n' unos
            //TODO

            outputLines.add(sb.toString());
        }

        return outputLines;
    }

    // Método principal para ejecutar la solución
    public static void main(String[] args) throws IOException {
        SurcosEnLaArena solver = new SurcosEnLaArena();
        String inputFile = "ruta/a/input.txt";    // Ruta del archivo de entrada
        String outputFile = "/ruta/a/output.txt";  // Ruta del archivo de salida
        solver.execute(inputFile, outputFile);
    }

}
