import java.util.*;

public class Solution {

  static Scanner in;

  public static boolean casoDePrueba() {

    // LEER CASO DE PRUEBA
    int n = in.nextInt();

    if (n == 0)
      return false;
    else {
      // CÓDIGO PRINCIPAL AQUÍ
      // Generar una cadena con 'n' unos
      
      
      System.out.println(sb.toString());

      return true;
    }

  } // casoDePrueba

  public static void main(String[] args) {

    in = new java.util.Scanner(System.in);

    while(casoDePrueba())
      ;

  } // main

} // class Solution
