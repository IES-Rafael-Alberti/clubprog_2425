// Esquema de la entrada: número de casos
import java.util.*;

public class Solution {

  static Scanner in;

  public static void casoDePrueba() {

    // Leer los valores de saldo inicial y cambio estimado
    int saldoInicial = in.nextInt();
    int cambioEstimado = in.nextInt();

    // Calcular el saldo final después de los ingresos y gastos
    // TODO

    // Determinar si el saldo final es mayor o igual a cero
    // TODO

  } // casoDePrueba

  public static void main(String[] args) {

    in = new java.util.Scanner(System.in);

    int numCasos = in.nextInt();
    for (int i = 0; i < numCasos; i++)
      casoDePrueba();

  } // main

} // class Solution
