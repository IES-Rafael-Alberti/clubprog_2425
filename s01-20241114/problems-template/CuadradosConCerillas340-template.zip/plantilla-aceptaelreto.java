import java.util.*;

public class Solution {

    static Scanner in;

    /**
     * Método que procesa un caso de prueba.
     * Lee los valores N y M, calcula y muestra el número total de cerillas necesarias.
     */
    public static void casoDePrueba() {

        // Lee los dos números N y M para el caso de prueba
        int N = in.nextInt(); // Número de cuadrados en horizontal
        int M = in.nextInt(); // Número de cuadrados en vertical

        // Calcula el número total de cerillas necesarias
        // TODO
        

        // Imprime el resultado
        System.out.println(totalMatches);

    } // casoDePrueba

    public static void main(String[] args) {

        in = new java.util.Scanner(System.in);

        // Lee el número de casos de prueba
        int numCasos = in.nextInt();
        for (int i = 0; i < numCasos; i++) {
            casoDePrueba();
        }

    } // main

} // class Solution