// Esquema de la entrada: número de casos
import java.util.*;

public class Solution {

  static Scanner in;

  public static void casoDePrueba() {

    // Leer la descripción de la carretera
    String road = in.next();

    // TODO: Implementar la lógica para calcular 'tunnelCount'

    // Imprimir el resultado para el caso actual
    System.out.println(tunnelCount);

  } // casoDePrueba

  public static void main(String[] args) {

    in = new java.util.Scanner(System.in);

    int numCasos = in.nextInt();
    for (int i = 0; i < numCasos; i++)
      casoDePrueba();

  } // main

} // class Solution
