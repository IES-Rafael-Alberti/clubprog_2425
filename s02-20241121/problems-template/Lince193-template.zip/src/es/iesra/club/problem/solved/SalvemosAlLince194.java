package es.iesra.club.problem.solved;

import es.iesra.club.problem.solver.ProblemSolver;
import java.io.*;
import java.util.*;

/**
 * Clase que resuelve el problema de calcular el número mínimo de túneles para evitar que los linces crucen las carreteras.
 */
public class SalvemosAlLince194 extends ProblemSolver {

    @Override
    protected List<String> process(List<String> inputLines) {
        List<String> outputLines = new ArrayList<>();

        // Leer el número de casos de prueba
        int numCasos = Integer.parseInt(inputLines.get(0));
        int currentLine = 1;

        // Procesar cada caso de prueba
        for (int i = 0; i < numCasos; i++) {
            // Leer la descripción de la carretera
            String road = inputLines.get(currentLine);
            currentLine++;

            // Calcular el número mínimo de túneles necesarios
            int tunnelCount = calcularMinimoTuneles(road);

            // Añadir el resultado a la lista de salida
            outputLines.add(String.valueOf(tunnelCount));
        }

        return outputLines;
    }

    /**
     * Calcula el número mínimo de túneles necesarios para una carretera dada.
     * @param road Cadena que representa la carretera ('.' y 'X').
     * @return Número mínimo de túneles necesarios.
     */
    private int calcularMinimoTuneles(String road) {
        // TODO
        return 0; // Valor de retorno provisional
    }

    // Método principal para ejecutar la solución
    public static void main(String[] args) throws IOException {
        SalvemosAlLince194 solver = new SalvemosAlLince194();
        String inputFile = "ruta/a/input.txt";    // Ruta del archivo de entrada
        String outputFile = "ruta/a/output.txt";  // Ruta del archivo de salida
        solver.execute(inputFile, outputFile);
    }
}