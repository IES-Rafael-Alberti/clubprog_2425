import java.util.*;

public class Solution {

    static Scanner in;

    public static void casoDePrueba() {

        // Leer el número de personas en la cola
        int N = Integer.parseInt(in.nextLine());

        // Leer los números de butaca y convertirlos a enteros
        String[] seatNumbersStr = in.nextLine().split(" ");
        int[] seats = new int[N];
        for (int i = 0; i < N; i++) {
            seats[i] = Integer.parseInt(seatNumbersStr[i]);
        }

        // TODO: Implementar la solución del problema

        // TODO: Imprimir el resultado apropiado

    } // casoDePrueba

    public static void main(String[] args) {

        in = new java.util.Scanner(System.in);

        int numCasos = Integer.parseInt(in.nextLine());
        for (int i = 0; i < numCasos; i++)
            casoDePrueba();

    } // main

} // class Solution
