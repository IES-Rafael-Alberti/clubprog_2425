package es.iesra.club.problem.solved;

import es.iesra.club.problem.solver.ProblemSolver;
import java.io.*;
import java.util.*;

/**
 * Clase que resuelve el problema "Entrando al cine".
 */
public class EntrandoAlCine221 extends ProblemSolver {

    @Override
    protected List<String> process(List<String> inputLines) {
        List<String> outputLines = new ArrayList<>();

        int lineIndex = 0;
        // Leer el número de casos de prueba
        int numCasos = Integer.parseInt(inputLines.get(lineIndex));
        lineIndex++;

        // Procesar cada caso de prueba
        for (int i = 0; i < numCasos; i++) {
            // Leer el número de personas en la cola
            int N = Integer.parseInt(inputLines.get(lineIndex));
            lineIndex++;

            // Leer los números de butaca de la línea correspondiente
            String[] seatNumbersStr = inputLines.get(lineIndex).split(" ");
            lineIndex++;

            // Convertir los números de butaca a un arreglo de enteros
            int[] seats = new int[N];
            for (int j = 0; j < N; j++) {
                seats[j] = Integer.parseInt(seatNumbersStr[j]);
            }

            // Procesar el caso y añadir el resultado a la lista de salida
            String result = processCase(seats);
            outputLines.add(result);
        }

        return outputLines;
    }

    /**
     * Procesa un caso individual y determina si Ramiro puede abrir la segunda puerta.
     * @param seats Arreglo con los números de butaca de las personas en la cola.
     * @return "SI X" si puede abrir la puerta, donde X es el número de personas que se quedan en su puerta; "NO" en caso contrario.
     */
    private String processCase(int[] seats) {
        int N = seats.length;
        int oddStartIndex = -1; // Índice donde comienzan las butacas impares

        // TODO: Implementar la lógica para determinar si Ramiro puede abrir la segunda puerta

        // Devolver el resultado correspondiente
        // TODO

        return ""; // Placeholder return statement
    }

    // Método principal para ejecutar la solución
    public static void main(String[] args) throws IOException {
        EntrandoAlCine221 solver = new EntrandoAlCine221();
        String inputFile = "ruta/a/input.txt";    // Ruta del archivo de entrada
        String outputFile = "ruta/a/output.txt";  // Ruta del archivo de salida
        solver.execute(inputFile, outputFile);
    }
}