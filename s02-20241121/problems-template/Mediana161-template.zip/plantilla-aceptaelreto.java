// Problema 161: Cálculo de la Mediana
import java.util.*;

public class Solution {

    static Scanner in;

    public static boolean casoDePrueba() {

        // LEER CASO DE PRUEBA
        int numValores = in.nextInt();

        // Comprobar si es el caso final
        if (numValores == 0)
            return false;
        else {
            // Leer los valores del conjunto
            List<Integer> valores = new ArrayList<>();
            for (int i = 0; i < numValores; i++) {
                valores.add(in.nextInt());
            }

            // Ordenar los valores
            // TODO: Ordenar la lista 'valores'

            // Calcular la mediana
            int dobleMediana;
            // TODO: Calcular 'dobleMediana' según si 'numValores' es par o impar

            // Imprimir el resultado
            System.out.println(dobleMediana);

            return true;
        }

    } // casoDePrueba

    public static void main(String[] args) {

        in = new Scanner(System.in);

        while (casoDePrueba())
            ;

    } // main

} // class Solution
