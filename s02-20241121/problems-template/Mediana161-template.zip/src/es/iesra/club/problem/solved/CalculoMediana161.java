package es.iesra.club.problem.solved;

import es.iesra.club.problem.solver.ProblemSolver;
import java.io.*;
import java.util.*;

/**
 * Clase que resuelve el problema 161: Cálculo de la Mediana.
 * Calcula el doble de la mediana de conjuntos de números positivos.
 */
public class CalculoMediana161 extends ProblemSolver {

    @Override
    protected List<String> process(List<String> inputLines) {
        List<String> outputLines = new ArrayList<>();
        int index = 0;

        while (index < inputLines.size()) {
            // Leer el número de valores del conjunto
            int numValores = Integer.parseInt(inputLines.get(index).trim());
            index++;

            // Verificar si es el caso final
            if (numValores == 0) {
                break;
            }

            // Leer los valores del conjunto
            String[] tokens = inputLines.get(index).trim().split("\\s+");
            index++;

            // Convertir los valores a una lista de enteros
            List<Integer> valores = new ArrayList<>();
            for (String token : tokens) {
                valores.add(Integer.parseInt(token));
            }

            // TODO: Implementar la lógica para calcular el doble de la mediana
            int dobleMediana = 0;

            // Añadir el resultado a la lista de salida
            outputLines.add(String.valueOf(dobleMediana));
        }

        return outputLines;
    }

    // Método principal para ejecutar la solución
    public static void main(String[] args) throws IOException {
        CalculoMediana161 solver = new CalculoMediana161();
        String inputFile = "ruta/a/input.txt";    // Ruta del archivo de entrada
        String outputFile = "ruta/a/output.txt";  // Ruta del archivo de salida
        solver.execute(inputFile, outputFile);
    }
}
