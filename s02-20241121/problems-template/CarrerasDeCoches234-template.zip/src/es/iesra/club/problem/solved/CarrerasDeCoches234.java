package es.iesra.club.problem.solved;

import es.iesra.club.problem.solver.ProblemSolver;
import java.io.*;
import java.util.*;

/**
 * Clase que resuelve el problema de maximizar el número de coches que pueden funcionar
 * dados los voltajes de las pilas y el voltaje mínimo requerido.
 */
public class CarrerasDeCoches234 extends ProblemSolver {

    @Override
    protected List<String> process(List<String> inputLines) {
        List<String> outputLines = new ArrayList<>();

        int numCasos = Integer.parseInt(inputLines.get(0));
        int currentLine = 1;

        for (int i = 0; i < numCasos; i++) {
            // Leer N y V
            String[] firstLine = inputLines.get(currentLine).split(" ");
            int N = Integer.parseInt(firstLine[0]);
            int V = Integer.parseInt(firstLine[1]);
            currentLine++;

            // Leer los voltajes
            String[] voltagesStr = inputLines.get(currentLine).split(" ");
            currentLine++;

            int[] voltages = new int[N];
            for (int j = 0; j < N; j++) {
                voltages[j] = Integer.parseInt(voltagesStr[j]);
            }

            // Resolver el caso
            int maxCoches = maximizarCoches(voltages, V);

            outputLines.add(String.valueOf(maxCoches));
        }

        return outputLines;
    }

    /**
     * Calcula el número máximo de coches que pueden funcionar
     * emparejando pilas cuya suma de voltajes sea al menos V.
     * @param voltages Array con los voltajes de las pilas.
     * @param V Voltaje mínimo requerido para un coche.
     * @return Número máximo de coches que pueden funcionar.
     */
    private int maximizarCoches(int[] voltages, int V) {
        // TODO: Implementar la lógica para maximizar el número de coches
        int numPairs = 0;
        
        return numPairs;
    }

    // Método principal para ejecutar la solución
    public static void main(String[] args) throws IOException {
        CarrerasDeCoches234 solver = new CarrerasDeCoches234();
        String inputFile = "ruta/a/input.txt";    // Ruta del archivo de entrada
        String outputFile = "ruta/a/output.txt";  // Ruta del archivo de salida
        solver.execute(inputFile, outputFile);
    }
}