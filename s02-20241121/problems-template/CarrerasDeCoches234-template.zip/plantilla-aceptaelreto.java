// Esquema de la entrada: número de casos
import java.util.*;
import java.io.*;

public class Solution {

  static Scanner in;

  public static void casoDePrueba() {
    // Leer N y V
    int N = in.nextInt();
    int V = in.nextInt();

    int[] voltages = new int[N];
    for (int i = 0; i < N; i++) {
        voltages[i] = in.nextInt();
    }

    // Resolver el caso
    int maxCoches = maximizarCoches(voltages, V);
    System.out.println(maxCoches);
  } // casoDePrueba

  /**
   * Calcula el número máximo de coches que pueden funcionar
   * emparejando pilas cuya suma de voltajes sea al menos V.
   * @param voltages Array con los voltajes de las pilas.
   * @param V Voltaje mínimo requerido para un coche.
   * @return Número máximo de coches que pueden funcionar.
   */
  static int maximizarCoches(int[] voltages, int V) {
    // TODO: Implementar el algoritmo para maximizar el número de coches

    int numPairs = 0;

    return numPairs;
  }

  public static void main(String[] args) {
    in = new java.util.Scanner(System.in);

    int numCasos = in.nextInt();
    for (int i = 0; i < numCasos; i++) {
      casoDePrueba();
    }

  } // main

} // class Solution