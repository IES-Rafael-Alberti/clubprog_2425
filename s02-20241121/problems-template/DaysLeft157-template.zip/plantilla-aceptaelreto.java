import java.util.*;

public class Solution {

    public static void main(String[] args) {

        Scanner in = new Scanner(System.in);

        // Leer el número de casos de prueba
        int numCasos = in.nextInt();

        // Días en cada mes para un año no bisiesto
        int[] diasPorMes = {
            31, // Enero
            28, // Febrero
            31, // Marzo
            30, // Abril
            31, // Mayo
            30, // Junio
            31, // Julio
            31, // Agosto
            30, // Septiembre
            31, // Octubre
            30, // Noviembre
            31  // Diciembre
        };

        // Días acumulados hasta el mes anterior
        int[] diasAcumulados = new int[12];
        diasAcumulados[0] = 0; // Enero no tiene acumulado
        for (int i = 1; i < 12; i++) {
            diasAcumulados[i] = diasAcumulados[i - 1] + diasPorMes[i - 1];
        }

        // Procesar cada caso de prueba
        for (int i = 0; i < numCasos; i++) {
            // Leer día y mes
            int dia = in.nextInt();
            int mes = in.nextInt();

            // TODO: Calcular los días que faltan hasta Nochevieja
            // int numeroDia = ...
            // int diasFaltan = ...

            // Mostrar el resultado
            System.out.println(diasFaltan);
        }

        in.close();
    }

}