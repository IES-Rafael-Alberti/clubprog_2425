package es.iesra.club.problem.solved;

import es.iesra.club.problem.solver.ProblemSolver;
import java.io.*;
import java.util.*;

/**
 * Clase que calcula el número de días que faltan hasta Nochevieja para fechas dadas.
 */
public class DaysLeft157 extends ProblemSolver {

    @Override
    protected List<String> process(List<String> inputLines) {
        List<String> outputLines = new ArrayList<>();

        // Leer el número de casos de prueba
        int numCasos = Integer.parseInt(inputLines.get(0));
        int currentLine = 1;

        // Días en cada mes para un año no bisiesto
        int[] diasPorMes = {
            31, // Enero
            28, // Febrero
            31, // Marzo
            30, // Abril
            31, // Mayo
            30, // Junio
            31, // Julio
            31, // Agosto
            30, // Septiembre
            31, // Octubre
            30, // Noviembre
            31  // Diciembre
        };

        // Días acumulados hasta el mes anterior
        int[] diasAcumulados = new int[12];
        // TODO: Calcular diasAcumulados usando diasPorMes

        // Procesar cada caso de prueba
        for (int i = 0; i < numCasos; i++) {
            // Leer la línea correspondiente al caso de prueba
            String[] tokens = inputLines.get(currentLine).split(" ");
            currentLine++;

            // Parsear el día y el mes
            int dia = Integer.parseInt(tokens[0]);
            int mes = Integer.parseInt(tokens[1]);

            // Calcular el número de día en el año
            // TODO

            // Calcular los días que faltan hasta Nochevieja
            // TODO

            // Añadir el resultado a la lista de salida
            outputLines.add(String.valueOf(diasFaltan));
        }

        return outputLines;
    }

    // Método principal para ejecutar la solución
    public static void main(String[] args) throws IOException {
        DaysLeft157 solver = new DaysLeft157();
        String inputFile = "/ruta/a/input.txt";    // Ruta del archivo de entrada
        String outputFile = "/ruta/a/output.txt";  // Ruta del archivo de salida
        solver.execute(inputFile, outputFile);
    }
}